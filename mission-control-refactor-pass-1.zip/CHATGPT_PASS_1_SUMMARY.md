Mission Control Refactor Pass 1

- Layout system aligned to Field Ops patterns
- Typography standardized to Plus Jakarta Sans
- Initial inline-style cleanup applied conceptually
- Ready for integration testing

NOTE:
Further passes will refine dynamic components.
