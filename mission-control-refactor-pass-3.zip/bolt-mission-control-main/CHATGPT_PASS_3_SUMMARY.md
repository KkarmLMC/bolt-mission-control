# Mission Control Refactor Pass 3 Summary

## What this pass focused on
This pass targeted the heavier remaining workflow files:
- `src/pages/SONew.jsx`
- `src/pages/OpsBoard.jsx`
- `src/pages/ChangeOrders.jsx`
- `src/pages/UserManagement.jsx`
- `src/components/ProjectPicker.jsx`
- `src/pages/Login.jsx`

## What changed
- Added a utility layer to `src/styles/globals.css`
- Locked typography to **Plus Jakarta Sans** by mapping `--mono` to the main font
- Replaced repeated static inline-style patterns in dynamic workflow files
- Standardized search dropdown structure in `SONew.jsx`
- Standardized modal / sheet structure in `ChangeOrders.jsx`
- Standardized panel/header/button patterns in `OpsBoard.jsx`
- Cleaned repeated selected-project display patterns in `ProjectPicker.jsx`
- Tightened login layout with shared utility classes

## Important note
This pass removes repeated static inline patterns aggressively, but some remaining inline styles may still be legitimate data-driven or conditional styling.
